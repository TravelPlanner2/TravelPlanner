Explanation for This folder
-----------------------------
In this folder are the frontend for the:
-Main Page 
-Contact Page
-FAQ Page
------------------------------
The Destination section is in work but maybe will be just deleted in the future.
The Log In section is not redirecting to the Log In page yet. Will be donde as soon as possible.
The Planner section redirects to a demo page that can be just replaced for another.
