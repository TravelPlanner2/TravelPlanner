package net.javaguides.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.javaguides.springboot.model.UserChoices;

public interface UserChoicesRepository extends JpaRepository<UserChoices, Long>{

}
